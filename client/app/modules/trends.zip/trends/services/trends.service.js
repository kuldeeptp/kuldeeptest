(function () {
  'use strict';
  angular
    .module('com.module.trends')
    .service('TrendsService', function ($state, CoreService, Trend, gettextCatalog) {

      this.getTrends = function () {
        return Trend.find().$promise;
      };

      this.getTrend = function (code) {
        return Trend.find({
            filter: {
                where: {code: code}
            }
        }).$promise;
      };

    });

})();
