(function () {
  'use strict';
  angular
    .module('com.module.trends')
    .config(function ($stateProvider) {
      $stateProvider
        .state('app.trends', {
          abstract: true,
          url: '/trends',
          templateUrl: 'modules/trends/views/main.html'
        })
        .state('app.trends.list', {
          url: '',
          templateUrl: 'modules/trends/views/list.html',
          controllerAs: 'ctrl',
          controller: function (trends) {
            this.trends = trends;
          },
          resolve: {
            trends: function (TrendsService) {
              return TrendsService.getTrends();
            }
          }
        })

        .state('app.trends.view', {
          url: '/:code',
          templateUrl: 'modules/trends/views/view.html',
          controllerAs: 'ctrl',
          controller: function (trend) {
            this.trend = trend;
          },
          resolve: {
            trend: function ($stateParams, TrendsService) {
              return TrendsService.getTrend($stateParams.code);
            }
          }
        })
    });

})();
